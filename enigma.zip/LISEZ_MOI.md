## Projet Enigma 

### Objectif du projet

L'objectif de ce projet est de mettre en oeuvre un jeu en 2 niveau se basant sur la librairie python pygame. 

#### Le premier niveau du jeu
Ce premier niveau a pour objectif d'afficher une aire de jeu ayant une taille largeur x hauteur se basant sur un tableau en deux dimensions préinitialisé.
Ce tableau est composé de valeurs indiquant le type de pixel:

* 'm' pour le pixel mur
* 'c' pour le pixel coffre fermé

La balle est inséré au démarrage dans une position libre au developpeur.

A chaque contact de la balle sur les coffres, ces derniers deviennent des coffres vide.


#### Le deuxieme niveau
Ce niveau est libre en terme de développement. 

### Installation
Python 2.6 ou 3.x doit etre installé sur votre système d'exploitation.
Le dossier enigma peut etre installé sur votre système Windows.
Le dossier comprends les compsants suivants:
* Installer les librairies via pip install: pygame, pandas, lxml 
* Le fichier source python 
* Les sources d'images (*.png)
* Le présent document d'explication 'Lisez Moi' écrit en language markdown pour etre intégré dans un repertoire communautaire de type github.  

### Guide d'utilisation

La balle rebondit sur les murs et les coffres. L'orientation et la direction de la balle peut etre fait via les touches UP, DOWN, LEFT et RIGHT. Ces touches orientant la balle.
